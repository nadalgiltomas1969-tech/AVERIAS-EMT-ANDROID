package com.averiasemt.app

import android.app.Activity
import android.content.Intent
import android.net.Uri
import android.os.Bundle
import android.webkit.JavascriptInterface
import android.webkit.WebChromeClient
import android.webkit.WebView
import android.webkit.WebViewClient
import java.io.BufferedReader
import java.io.InputStreamReader
import java.util.zip.ZipInputStream

class MainActivity: Activity() {
    private lateinit var web: WebView
    override fun onCreate(state: Bundle?) { super.onCreate(state)
        web=WebView(this); setContentView(web)
        web.settings.javaScriptEnabled=true; web.settings.domStorageEnabled=true
        web.webViewClient=WebViewClient(); web.webChromeClient=WebChromeClient(); web.addJavascriptInterface(Bridge(),"Android")
        web.loadUrl("file:///android_asset/index.html")
        web.setDownloadListener { _,_,_,_,_ -> }
        web.postDelayed({ handleIntent(intent) },500)
    }
    override fun onNewIntent(i: Intent){ super.onNewIntent(i); intent=i; handleIntent(i) }
    private fun handleIntent(i: Intent){ if(i.action==Intent.ACTION_SEND){ val u=i.getParcelableExtra<Uri>(Intent.EXTRA_STREAM); if(u!=null) importUri(u) else i.getStringExtra(Intent.EXTRA_TEXT)?.let{ sendText(it,"WhatsApp") } } }
    private fun importUri(uri:Uri){ try { val name=uri.lastPathSegment?:"archivo"; val stream=contentResolver.openInputStream(uri)?:return
        val text=if(name.lowercase().endsWith(".zip")){ val z=ZipInputStream(stream); val sb=StringBuilder(); var e=z.nextEntry; while(e!=null){ if(!e.isDirectory && e.name.lowercase().endsWith(".txt")){ sb.append(z.bufferedReader(Charsets.UTF_8).readText()).append("\n") }; e=z.nextEntry }; z.close(); sb.toString() } else BufferedReader(InputStreamReader(stream,Charsets.UTF_8)).readText()
        sendText(text,name)
    } catch(e:Exception){ sendError(e.message?:"Error al leer el archivo") } }
    private fun sendText(t:String,n:String){ val js="window.importWhatsapp("+org.json.JSONObject.quote(t)+","+org.json.JSONObject.quote(n)+")"; web.post{web.evaluateJavascript(js,null)} }
    private fun sendError(t:String){ web.post{web.evaluateJavascript("window.showError("+org.json.JSONObject.quote(t)+")",null)} }
    inner class Bridge { @JavascriptInterface fun chooseFile(){ runOnUiThread { startActivityForResult(Intent(Intent.ACTION_OPEN_DOCUMENT).apply{addCategory(Intent.CATEGORY_OPENABLE);type="*/*";putExtra(Intent.EXTRA_MIME_TYPES,arrayOf("text/plain","application/zip","application/octet-stream"))},42) } } }
    override fun onActivityResult(r:Int,c:Int,d:Intent?){ super.onActivityResult(r,c,d); if(r==42&&c==RESULT_OK)d?.data?.let{importUri(it)} }
}
