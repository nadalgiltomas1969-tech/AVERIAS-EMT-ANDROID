AVERÍAS EMT Android v0.1 FUENTE
- Importa TXT o ZIP exportado de WhatsApp.
- También aparece como destino de Compartir para TXT/ZIP.
- Huellas SHA-256 locales para evitar duplicados.
- Elimina citas visibles y datos personales básicos antes de guardar.
- Registro local persistente en WebView/localStorage.
- Filtros por mes y climatización.

Para compilar: Android Studio / Gradle con Android SDK 35.
